
import React from 'react';
import { UserRole } from '../types';

interface SidebarProps {
  role: UserRole;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const MiniLogo = () => (
  <svg viewBox="0 0 100 100" className="w-10 h-10" xmlns="http://www.w3.org/2000/svg">
    <path d="M30 40 L45 70 L35 60 L25 70 Z" fill="#fff" />
    <path d="M45 30 L60 60 L50 50 L40 60 Z" fill="#fff" />
    <path d="M60 20 L75 50 L65 40 L55 50 Z" fill="#fff" />
    <line x1="25" y1="35" x2="65" y2="15" stroke="#e11d48" strokeWidth="6" strokeLinecap="round" />
  </svg>
);

const Sidebar: React.FC<SidebarProps> = ({ role, activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '🌀', roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.TECHNICAL_TEAM, UserRole.STORE_KEEPER] },
    { id: 'inventory', label: 'Inventory', icon: '📦', roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN, UserRole.STORE_KEEPER] },
    { id: 'my-requests', label: 'Requisitions', icon: '📝', roles: [UserRole.TECHNICAL_TEAM] },
    { id: 'confirm-receipt', label: 'Handover', icon: '🔐', roles: [UserRole.TECHNICAL_TEAM] },
    { id: 'approvals', label: 'Approvals', icon: '✅', roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN] },
    { id: 'issuing', label: 'Issuance', icon: '📤', roles: [UserRole.SUPER_ADMIN, UserRole.STORE_KEEPER] },
    { id: 'reports', label: 'Analytics', icon: '📉', roles: [UserRole.SUPER_ADMIN, UserRole.ADMIN] },
    { id: 'users', label: 'Personnel', icon: '👥', roles: [UserRole.SUPER_ADMIN] },
  ];

  const filteredItems = menuItems.filter(item => item.roles.includes(role));

  return (
    <div className="w-72 bg-[#0f172a] text-slate-400 flex flex-col shrink-0 border-r border-slate-800 shadow-[20px_0_40px_rgba(0,0,0,0.3)] z-40">
      <div className="h-24 flex items-center px-8 gap-4 bg-[#0a0f1d] border-b border-slate-800/50">
        <div className="relative">
          <div className="absolute inset-0 bg-indigo-500/20 blur-md rounded-full animate-pulse"></div>
          <MiniLogo />
        </div>
        <div className="flex flex-col">
          <span className="text-sm font-black text-white tracking-[0.2em] leading-none mb-1">WIPL</span>
          <span className="text-[10px] font-black text-indigo-500 uppercase tracking-tighter opacity-80">STORE MASTER PRO</span>
        </div>
      </div>
      
      <nav className="flex-1 py-10 px-5 space-y-2">
        {filteredItems.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-4 px-5 py-4 rounded-[20px] text-[11px] font-black uppercase tracking-[0.2em] transition-all duration-300 relative group ${
              activeTab === item.id 
                ? 'bg-[#1e1b4b] text-white shadow-[0_10px_20px_-5px_rgba(67,56,120,0.4)] border border-indigo-500/30' 
                : 'hover:bg-slate-800/50 hover:text-white'
            }`}
          >
            <span className={`text-lg opacity-70 group-hover:scale-110 transition-transform ${activeTab === item.id ? 'opacity-100' : ''}`}>
              {item.icon}
            </span>
            {item.label}
            {activeTab === item.id && (
              <div className="absolute right-4 w-1.5 h-1.5 rounded-full bg-indigo-500 shadow-[0_0_8px_#6366f1]"></div>
            )}
          </button>
        ))}
      </nav>
      
      <div className="p-8 border-t border-slate-800/50">
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-3 text-[9px] text-emerald-400 bg-emerald-500/5 px-4 py-3 rounded-2xl border border-emerald-500/10 uppercase font-black tracking-widest">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Node Sync Active
          </div>
          <p className="text-[8px] uppercase tracking-[0.3em] text-slate-600 font-black text-center">v2.8.4 Version</p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
