
import React, { useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { db } from '../services/db';
import { getInventoryInsights } from '../services/gemini';
import { RequestStatus } from '../types';

const Dashboard: React.FC = () => {
  const [items] = useState(db.getItems());
  const [requests] = useState(db.getRequests());
  const [aiInsight, setAiInsight] = useState<string>('Initializing Strategy Engine...');
  const [loadingAi, setLoadingAi] = useState(true);
  const [isQuotaExhausted, setIsQuotaExhausted] = useState(false);
  const [isKeyInvalid, setIsKeyInvalid] = useState(false);

  const fetchInsights = async () => {
    setLoadingAi(true);
    setIsQuotaExhausted(false);
    setIsKeyInvalid(false);
    
    const insight = await getInventoryInsights(items, requests);
    
    if (insight === "QUOTA_EXHAUSTED") {
      setIsQuotaExhausted(true);
      setAiInsight('');
    } else if (insight === "KEY_INVALID") {
      setIsKeyInvalid(true);
      setAiInsight('');
    } else {
      setAiInsight(insight || 'Operational data synthesis complete.');
    }
    setLoadingAi(false);
  };

  useEffect(() => {
    fetchInsights();
  }, [items, requests]);

  const handleSelectKey = async () => {
    try {
      await (window as any).aistudio.openSelectKey();
      fetchInsights();
    } catch (err) {
      console.error("Failed to open key selection dialog", err);
    }
  };

  const totalStock = items.reduce((sum, item) => sum + item.currentStock, 0);
  const lowStockCount = items.filter(item => item.currentStock <= item.minStockReq).length;
  const pendingRequests = requests.filter(r => r.status === RequestStatus.PENDING).length;

  const categoryData = Object.entries(
    items.reduce((acc: Record<string, number>, item) => {
      acc[item.category] = (acc[item.category] || 0) + 1;
      return acc;
    }, {})
  ).map(([name, value]) => ({ name, value }));

  const currentDate = new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  const COLORS = ['#433878', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#6366f1'];

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-1000">
      {/* Premium Rebranded Header */}
      <div className="relative overflow-hidden bg-white p-12 rounded-[56px] border border-slate-200 shadow-[0_30px_70px_-15px_rgba(0,0,0,0.08)]">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-500/5 rounded-full blur-[120px] -mr-40 -mt-40 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500/5 rounded-full blur-[100px] -ml-20 -mb-20"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-10">
          <div className="flex-1">
            <div className="flex items-center gap-4 mb-5">
              <span className="h-[2px] w-20 bg-[#433878]"></span>
              <span className="text-[11px] font-black text-[#433878] uppercase tracking-[0.6em]">SIte Office</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tighter leading-none mb-4">
              WATSUN <span className="text-[#433878] font-light italic">INFRABUILD PRIVATE LIMITED</span>
            </h1>
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_10px_#10b981]"></div>
                <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest">SUSSTATION</h2>
              </div>
              <div className="w-[1px] h-5 bg-slate-200"></div>
              <p className="text-xs font-black text-[#433878] uppercase tracking-[0.4em]">STORE DASHBOARD</p>
            </div>
          </div>
          
          <div className="flex flex-col items-end">
            <div className="bg-[#1e1b4b] text-white px-8 py-5 rounded-[28px] shadow-[0_20px_40px_rgba(30,27,75,0.3)] border border-white/5 mb-3 group hover:scale-105 transition-transform duration-500">
              <div className="flex items-center gap-5">
                <div className="flex flex-col">
                  <span className="text-[9px] font-black text-indigo-400 uppercase tracking-widest leading-none mb-2">Access Date</span>
                  <span className="text-xl font-black tracking-tighter leading-none font-mono uppercase">{currentDate}</span>
                </div>
                <div className="w-10 h-10 rounded-2xl bg-indigo-900/50 flex items-center justify-center border border-indigo-500/20 shadow-inner">
                  <span className="text-xl">📅</span>
                </div>
              </div>
            </div>
            <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest opacity-60">System Status: Active</p>
          </div>
        </div>
      </div>

      {/* Advanced Glass KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { label: 'Total Assets', value: items.length, icon: '🛠️', color: '#433878', sub: 'Managed Items' },
          { label: 'Stock Volume', value: totalStock, icon: '🏗️ ', color: '#3b82f6', sub: 'Aggregate Units' },
          { label: 'Critical Alert', value: lowStockCount, icon: '⚠️', color: '#ef4444', sub: 'Low Stock Risk' },
          { label: 'Pending Auth', value: pendingRequests, icon: '📝', color: '#f59e0b', sub: 'Active Requisitions' },
        ].map((stat, i) => (
          <div key={i} className="group bg-white p-10 rounded-[44px] border border-slate-200 shadow-sm hover:shadow-[0_40px_80px_-20px_rgba(0,0,0,0.1)] hover:-translate-y-2 transition-all duration-700 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-slate-50 group-hover:bg-indigo-50 transition-colors rounded-bl-[60px] -mr-8 -mt-8"></div>
            <div className="relative z-10">
              <div className="w-16 h-16 rounded-3xl bg-slate-50 flex items-center justify-center text-3xl mb-8 group-hover:scale-110 transition-transform duration-700 shadow-inner border border-slate-100">
                {stat.icon}
              </div>
              <p className="text-4xl font-black text-slate-900 tracking-tighter mb-1">{stat.value.toLocaleString()}</p>
              <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4">{stat.label}</h4>
              <div className="h-[2px] w-full bg-slate-100 rounded-full overflow-hidden">
                <div 
                  className="h-full transition-all duration-1000 ease-in-out" 
                  style={{ width: '65%', backgroundColor: stat.color }}
                ></div>
              </div>
              <p className="text-[9px] font-black text-slate-300 mt-4 uppercase tracking-widest">{stat.sub}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-10">
          <div className="bg-white p-12 rounded-[56px] border border-slate-200 shadow-sm overflow-hidden relative">
            <div className="flex items-center justify-between mb-12">
              <div>
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-[0.3em]">Operational Metrics</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase mt-2 tracking-widest">Inventory Distribution Matrix</p>
              </div>
              <div className="px-4 py-2 bg-slate-50 border border-slate-100 rounded-2xl text-[10px] font-black text-indigo-500 uppercase tracking-widest">Node Alpha Live</div>
            </div>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryData}>
                  <defs>
                    <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#433878" stopOpacity={1} />
                      <stop offset="100%" stopColor="#6366f1" stopOpacity={0.8} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="8 8" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="name" 
                    fontSize={11} 
                    tickLine={false} 
                    axisLine={false} 
                    tick={{fill: '#94a3b8', fontWeight: 900}} 
                    dy={20}
                  />
                  <YAxis 
                    fontSize={11} 
                    tickLine={false} 
                    axisLine={false} 
                    tick={{fill: '#94a3b8', fontWeight: 900}} 
                  />
                  <Tooltip 
                    cursor={{fill: '#f8fafc', radius: 12}}
                    contentStyle={{ borderRadius: '28px', border: 'none', boxShadow: '0 30px 60px -12px rgb(0 0 0 / 0.2)', fontSize: '12px', fontWeight: 'black', textTransform: 'uppercase' }} 
                  />
                  <Bar dataKey="value" fill="url(#barGradient)" radius={[14, 14, 0, 0]} barSize={60} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* NEURAL STRATEGY CONSOLE */}
        <div className="flex flex-col gap-10">
          <div className="bg-[#1e1b4b] text-white p-12 rounded-[64px] shadow-[0_50px_100px_-30px_rgba(0,0,0,0.5)] flex flex-col h-full border border-indigo-400/20 relative group">
            <div className="absolute top-0 right-0 p-10 opacity-20">
              <div className="flex gap-2">
                <div className="w-1.5 h-6 bg-indigo-500 rounded-full animate-pulse"></div>
                <div className="w-1.5 h-10 bg-indigo-500 rounded-full animate-pulse delay-75"></div>
                <div className="w-1.5 h-4 bg-indigo-500 rounded-full animate-pulse delay-150"></div>
              </div>
            </div>

            <div className="mb-12">
              <div className="flex items-center gap-4 mb-3">
                <div className="w-3 h-3 bg-blue-500 rounded-full animate-ping absolute opacity-50"></div>
                <div className="w-3 h-3 bg-blue-500 rounded-full relative shadow-[0_0_15px_#3b82f6]"></div>
                <h3 className="text-sm font-black text-white tracking-[0.3em] uppercase">Strategic AI Node</h3>
              </div>
              <p className="text-[10px] text-indigo-400 font-bold tracking-[0.4em] uppercase opacity-60">ADVANCED AGENT v5.2</p>
            </div>
            
            <div className="flex-1 overflow-y-auto custom-scrollbar pr-5 mb-12 font-mono text-[12px] text-indigo-100 leading-relaxed bg-black/30 p-8 rounded-[40px] border border-white/5 shadow-inner">
              {loadingAi ? (
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <span className="text-indigo-500">▹</span>
                    <div className="h-4 bg-indigo-900/50 rounded-full animate-pulse w-3/4"></div>
                  </div>
                  <div className="flex gap-4">
                    <span className="text-indigo-500">▹</span>
                    <div className="h-4 bg-indigo-900/50 rounded-full animate-pulse w-full"></div>
                  </div>
                  <div className="flex gap-4">
                    <span className="text-indigo-500">▹</span>
                    <div className="h-4 bg-indigo-900/50 rounded-full animate-pulse w-2/3"></div>
                  </div>
                </div>
              ) : (isQuotaExhausted || isKeyInvalid) ? (
                <div className="space-y-8 text-center py-6">
                  <div className="w-20 h-20 bg-indigo-900/50 rounded-full flex items-center justify-center mx-auto text-4xl shadow-inner border border-indigo-500/30">
                    🔑
                  </div>
                  <div>
                    <h4 className="text-[11px] font-black text-white uppercase tracking-[0.4em] mb-4">
                      {isQuotaExhausted ? "Quota Limit Reached" : "Node Authorization Required"}
                    </h4>
                    <p className="text-[11px] text-indigo-300 leading-relaxed italic opacity-80">
                      {isQuotaExhausted 
                        ? "The shared AI bandwidth is currently exhausted. Please authorize your own personal billing-enabled key to restore neural synthesis."
                        : "The current security token is invalid or has expired. Re-authentication is required."}
                    </p>
                  </div>
                  <button 
                    onClick={handleSelectKey}
                    className="w-full py-5 bg-white text-[#1e1b4b] text-[11px] font-black rounded-2xl hover:bg-blue-50 transition-all uppercase tracking-[0.3em] shadow-2xl flex items-center justify-center gap-4 active:scale-95 border-b-4 border-slate-200"
                  >
                    Authorize Personal Node
                  </button>
                  <p className="text-[9px] text-indigo-400 leading-relaxed uppercase font-black tracking-widest opacity-60">
                    Required: Paid GCP Project API Key <br/>
                    <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-blue-400 underline hover:text-blue-300">Billing Docs</a>
                  </p>
                </div>
              ) : (
                <div className="space-y-5">
                  {aiInsight.split('\n').map((line, i) => (
                    <p key={i} className="relative pl-8">
                      <span className="absolute left-0 text-indigo-500 opacity-60">▹</span>
                      {line}
                    </p>
                  ))}
                </div>
              )}
            </div>
            
            {!(isQuotaExhausted || isKeyInvalid) && (
              <button 
                className="w-full py-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-[11px] font-black rounded-[24px] transition-all shadow-[0_25px_50px_-10px_rgba(37,99,235,0.4)] uppercase tracking-[0.4em] active:scale-95 flex items-center justify-center gap-4"
                onClick={fetchInsights}
              >
                <span>⚡</span> Synchronize New Scan
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
