
import React, { useState } from 'react';
import { db } from '../services/db';
import { User, UserRole } from '../types';

interface UserManagementProps {
  currentUser: User;
}

const UserManagement: React.FC<UserManagementProps> = ({ currentUser }) => {
  const [users, setUsers] = useState<User[]>(db.getUsers());
  const [showAddModal, setShowAddModal] = useState(false);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    password: '',
    role: UserRole.TECHNICAL_TEAM,
    department: ''
  });

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUser.name || !newUser.email || !newUser.department || !newUser.password) {
      return alert("All fields including security token are required.");
    }

    const user: User = {
      ...newUser,
      id: `u-${Date.now()}`
    };

    db.addUser(user);
    db.addLog({
      userId: currentUser.id,
      userName: currentUser.name,
      action: `Created new user: ${user.name} (${user.role})`,
      module: 'User Management'
    });

    setUsers(db.getUsers());
    setShowAddModal(false);
    setNewUser({ name: '', email: '', password: '', role: UserRole.TECHNICAL_TEAM, department: '' });
  };

  const handleRemoveUser = (userId: string, userName: string) => {
    if (userId === currentUser.id) {
      return alert("Security Protocol: You cannot revoke your own administrative access.");
    }

    const confirmed = window.confirm(`CRITICAL SECURITY ACTION: Are you sure you want to permanently revoke system access for ${userName}? This will be logged in the irreversible audit trail.`);
    
    if (confirmed) {
      db.deleteUser(userId);
      // Immediately refresh local state
      const updatedUsers = db.getUsers();
      setUsers(updatedUsers);

      db.addLog({
        userId: currentUser.id,
        userName: currentUser.name,
        action: `SECURITY: Terminated access for user ID ${userId} (${userName})`,
        module: 'User Management'
      });
    }
  };

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case UserRole.SUPER_ADMIN: return 'bg-indigo-100 text-indigo-700 border-indigo-200';
      case UserRole.ADMIN: return 'bg-blue-100 text-blue-700 border-blue-200';
      case UserRole.TECHNICAL_TEAM: return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case UserRole.STORE_KEEPER: return 'bg-amber-100 text-amber-700 border-amber-200';
      default: return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Corporate Access Control</h2>
          <p className="text-sm text-slate-500">Manage organizational personnel and security clearance levels.</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="px-6 py-2.5 bg-[#433878] text-white rounded-xl font-bold text-sm hover:bg-[#312e81] transition-all shadow-lg shadow-indigo-100 flex items-center gap-2"
        >
          <span>➕</span> Provision New Member
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-[10px] uppercase font-black text-slate-400 tracking-widest border-b border-slate-200">
            <tr>
              <th className="px-8 py-5">Corporate Identity</th>
              <th className="px-8 py-5">Email Address</th>
              <th className="px-8 py-5">Department</th>
              <th className="px-8 py-5">Clearance Level</th>
              <th className="px-8 py-5 text-right">Security Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {users.map(user => (
              <tr key={user.id} className="hover:bg-slate-50 transition-colors group">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center font-bold text-[#433878] border border-slate-200">
                      {user.name.charAt(0)}
                    </div>
                    <span className="font-bold text-slate-900">{user.name}</span>
                  </div>
                </td>
                <td className="px-8 py-5 font-medium text-slate-500">{user.email}</td>
                <td className="px-8 py-5 text-slate-600 italic">{user.department}</td>
                <td className="px-8 py-5">
                  <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase border ${getRoleBadge(user.role)}`}>
                    {user.role}
                  </span>
                </td>
                <td className="px-8 py-5 text-right">
                  {user.id !== currentUser.id ? (
                    <button 
                      onClick={() => handleRemoveUser(user.id, user.name)}
                      className="inline-flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-xl transition-all"
                      title="Revoke System Access"
                    >
                      <span className="text-base">🗑️</span>
                      <span className="text-[10px] font-black uppercase tracking-widest">Revoke</span>
                    </button>
                  ) : (
                    <span className="inline-flex items-center gap-2 px-4 py-2 text-indigo-400 bg-indigo-50 border border-indigo-100 rounded-xl text-[10px] font-black uppercase tracking-widest italic">
                      Active Session
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <form onSubmit={handleAddUser} className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-200">
            <div className="px-8 py-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-slate-900">Provision New Member</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">WIPL Security Clearance</p>
              </div>
              <button 
                type="button" 
                onClick={() => setShowAddModal(false)} 
                className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-100 rounded-xl"
              >✕</button>
            </div>
            
            <div className="p-8 space-y-5">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Full Identity</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="e.g. Robert Wilson"
                  value={newUser.name}
                  onChange={e => setNewUser({...newUser, name: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Corporate Email</label>
                <input 
                  type="email" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="r.wilson@wipl.com"
                  value={newUser.email}
                  onChange={e => setNewUser({...newUser, email: e.target.value})}
                  required
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Security Token / Password</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
                  placeholder="Set initial password..."
                  value={newUser.password}
                  onChange={e => setNewUser({...newUser, password: e.target.value})}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Assigned Role</label>
                  <select 
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    value={newUser.role}
                    onChange={e => setNewUser({...newUser, role: e.target.value as UserRole})}
                  >
                    {Object.values(UserRole).map(role => (
                      <option key={role} value={role}>{role}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Department</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="e.g. Operations"
                    value={newUser.department}
                    onChange={e => setNewUser({...newUser, department: e.target.value})}
                    required
                  />
                </div>
              </div>
            </div>

            <div className="px-8 py-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button 
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-6 py-2.5 text-xs font-bold text-slate-500 hover:bg-slate-200 rounded-xl transition-colors"
              >
                CANCEL
              </button>
              <button 
                type="submit"
                className="px-8 py-2.5 bg-[#433878] text-white text-xs font-bold rounded-xl hover:bg-[#312e81] transition-all shadow-lg shadow-indigo-100"
              >
                AUTHORIZE ACCESS
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
