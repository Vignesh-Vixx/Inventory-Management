
import React from 'react';
import { User, UserRole } from '../types';
import Sidebar from './Sidebar';

interface LayoutProps {
  user: User;
  onLogout: () => void;
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ user, onLogout, children, activeTab, setActiveTab }) => {
  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans">
      {/* Sidebar */}
      <Sidebar 
        role={user.role} 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 bg-slate-50 relative">
        <header className="h-20 bg-white border-b border-slate-200/60 flex items-center justify-between px-10 shrink-0 z-30">
          <div className="flex items-center gap-4">
            <div className="w-1.5 h-6 bg-[#433878] rounded-full"></div>
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-[0.15em]">
              {activeTab.replace('-', ' ')}
            </h2>
          </div>
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-4 border-r border-slate-100 pr-8">
              <div className="w-10 h-10 rounded-2xl bg-[#433878] flex items-center justify-center text-white font-black text-sm shadow-lg shadow-indigo-100">
                {user.name.charAt(0)}
              </div>
              <div className="text-left">
                <p className="text-xs font-black text-slate-900 uppercase tracking-tight leading-none mb-1">{user.name}</p>
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-black text-indigo-500 uppercase tracking-widest">{user.role}</span>
                  <span className="text-slate-300 text-[8px]">•</span>
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{user.department}</span>
                </div>
              </div>
            </div>
            <button 
              onClick={onLogout}
              className="px-5 py-2.5 text-[10px] font-black text-red-500 hover:bg-red-50 rounded-xl transition-all border border-transparent hover:border-red-100 uppercase tracking-[0.2em]"
            >
              Terminate Session
            </button>
          </div>
        </header>
        
        <main className="flex-1 overflow-y-auto p-10 custom-scrollbar">
          <div className="max-w-[1600px] mx-auto">
            {children}
          </div>
        </main>

        {/* Floating Background Decorations */}
        <div className="fixed top-20 right-0 w-[500px] h-[500px] bg-indigo-500/5 blur-[120px] rounded-full -z-10 pointer-events-none"></div>
        <div className="fixed bottom-0 left-72 w-[500px] h-[500px] bg-blue-500/5 blur-[120px] rounded-full -z-10 pointer-events-none"></div>
      </div>
    </div>
  );
};

export default Layout;
