
import React, { useState } from 'react';
import { User } from '../types';
import { db } from '../services/db';

interface LoginProps {
  onLogin: (user: User) => void;
}

const ContinuumLogo = ({ className = "w-24 h-24" }) => (
  <svg viewBox="0 0 400 300" className={className} xmlns="http://www.w3.org/2000/svg">
    <text x="50%" y="40" textAnchor="middle" fontFamily="sans-serif" fontSize="60" fontWeight="900" fill="#433878" style={{ letterSpacing: '-0.05em' }}>CONTINUUM</text>
    <line x1="110" y1="130" x2="280" y2="70" stroke="#e11d48" strokeWidth="12" strokeLinecap="round" />
    <path d="M120 150 L180 280 L140 230 L100 280 Z" fill="#433878" />
    <path d="M180 120 L240 250 L200 200 L160 250 Z" fill="#433878" />
    <path d="M240 90 L300 220 L260 170 L220 220 Z" fill="#433878" />
  </svg>
);

const AdvancedEnergyGrid = () => (
  <div className="absolute inset-0 z-0 opacity-40 overflow-hidden pointer-events-none">
    <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <pattern id="grid" width="80" height="80" patternUnits="userSpaceOnUse">
          <path d="M 80 0 L 0 0 0 80" fill="none" stroke="#433878" strokeWidth="0.5" strokeOpacity="0.1" />
          <circle cx="0" cy="0" r="1" fill="#433878" fillOpacity="0.1" />
        </pattern>
        <radialGradient id="lightVignette" cx="50%" cy="50%" r="70%">
          <stop offset="0%" stopColor="white" stopOpacity="0" />
          <stop offset="100%" stopColor="white" stopOpacity="0.8" />
        </radialGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#grid)" />
      <rect width="100%" height="100%" fill="url(#lightVignette)" />
      <g stroke="#433878" fill="none" strokeWidth="1" opacity="0.1">
        <path d="M 0 100 L 200 100 L 250 150 L 800 150" strokeDasharray="5 5" />
        <path d="M 1200 800 L 1000 800 L 950 750 L 400 750" strokeDasharray="5 5" />
      </g>
    </svg>
  </div>
);

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsAuthenticating(true);
    
    setTimeout(() => {
      const user = db.getUsers().find(u => u.email === email && u.password === password);
      if (user) {
        onLogin(user);
      } else {
        setError('Security Protocol Violation: Invalid Node Credentials.');
        setIsAuthenticating(false);
      }
    }, 1200);
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden px-4 bg-slate-50">
      {/* Infrastructure Background with light overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center transition-transform duration-[20000ms] ease-linear scale-110"
        style={{ 
          backgroundImage: `linear-gradient(rgba(248, 250, 252, 0.8), rgba(248, 250, 252, 0.9)), url('https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=2070&auto=format&fit=crop')`,
          animation: 'slowPan 60s infinite alternate'
        }}
      />
      
      <style>{`
        @keyframes slowPan {
          from { transform: scale(1.05) translateX(-20px); }
          to { transform: scale(1.05) translateX(20px); }
        }
        .input-light {
          background: rgba(255, 255, 255, 0.8);
          border: 1px solid #e2e8f0;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .input-light:focus {
          background: white;
          border-color: #6366f1;
          box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.1), 0 8px 10px -6px rgba(99, 102, 241, 0.1);
        }
      `}</style>

      <AdvancedEnergyGrid />
      
      {/* Soft Glow Elements */}
      <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-indigo-500/5 blur-[120px] rounded-full pointer-events-none animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-blue-500/5 blur-[120px] rounded-full pointer-events-none animate-pulse delay-1000" />

      <div className="w-full max-w-lg z-10 animate-in fade-in zoom-in duration-1000">
        <div className="bg-white/70 backdrop-blur-3xl rounded-[64px] shadow-[0_40px_100px_-20px_rgba(0,0,0,0.08)] overflow-hidden border border-white/40 ring-1 ring-slate-200/50">
          <div className="p-10 md:p-16">
            <div className="flex justify-center mb-10 relative">
              <div className="absolute inset-0 bg-indigo-500/5 blur-[40px] rounded-full scale-150"></div>
              <ContinuumLogo className="w-64 h-auto relative" />
            </div>
            
            <div className="text-center mb-12">
              <div className="flex items-center justify-center gap-4 mb-4">
                <div className="h-[2px] w-8 bg-indigo-500/20"></div>
                <h1 className="text-3xl font-black text-slate-900 tracking-tighter leading-none">
                  STORE MASTER <span className="text-indigo-600 font-light italic">ADVANCED</span>
                </h1>
                <div className="h-[2px] w-8 bg-indigo-500/20"></div>
              </div>
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.6em]">Advanced management system</p>
            </div>
            
            {error && (
              <div className="mb-8 p-6 bg-red-50 border border-red-100 rounded-3xl flex items-center gap-4 text-red-600 animate-in slide-in-from-top-4 duration-300">
                <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center shrink-0">
                  <span className="text-xl">⚠️</span>
                </div>
                <p className="text-[11px] font-black uppercase tracking-widest leading-relaxed">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="group relative">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 ml-2 transition-colors group-focus-within:text-indigo-600">
                  User Name
                </label>
                <div className="relative">
                  <div className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 text-xl group-focus-within:text-indigo-600 transition-colors z-10">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </div>
                  <input 
                    type="email" 
                    className="input-light w-full pl-16 pr-8 py-5 rounded-[28px] text-slate-900 text-sm font-bold placeholder:text-slate-300 outline-none"
                    placeholder="authorized.user@wipl.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="group relative">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-4 ml-2 transition-colors group-focus-within:text-indigo-600">
                  Security Password
                </label>
                <div className="relative">
                  <div className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 text-xl group-focus-within:text-indigo-600 transition-colors z-10">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  </div>
                  <input 
                    type="password" 
                    className="input-light w-full pl-16 pr-8 py-5 rounded-[28px] text-slate-900 text-sm transition-all placeholder:text-slate-300 outline-none"
                    placeholder="••••••••••••"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                  />
                </div>
              </div>
              
              <div className="pt-4">
                <button 
                  type="submit"
                  disabled={isAuthenticating}
                  className="w-full py-6 bg-gradient-to-br from-[#433878] to-[#312e81] text-white rounded-[32px] font-black hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_25px_50px_-15px_rgba(67,56,120,0.3)] flex items-center justify-center gap-5 uppercase tracking-[0.4em] text-[11px] disabled:opacity-50 group relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                  {isAuthenticating ? (
                    <div className="flex items-center gap-4">
                      <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                      <span>Validating Network...</span>
                    </div>
                  ) : (
                    <>
                      <span>Initialize Session</span>
                      <svg className="w-5 h-5 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
          <div className="px-12 py-10 bg-slate-50/50 border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_15px_#10b981]"></div>
                <div className="absolute inset-0 bg-emerald-500/10 blur-sm rounded-full scale-150"></div>
              </div>
              <span className="text-[11px] font-black text-slate-500 uppercase tracking-widest leading-none">Continuum Gateway connected</span>
            </div>
            <span className="text-[10px] font-black text-indigo-500/40 uppercase tracking-tight">Node v2.9.1.PRO</span>
          </div>
        </div>
        
        {/* Decorative Footer */}
        <div className="mt-12 flex flex-col items-center gap-4 animate-in fade-in slide-in-from-bottom-4 duration-1000">
          <div className="flex items-center gap-6">
            <div className="h-[1px] w-16 bg-gradient-to-r from-transparent to-slate-200"></div>
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.5em] text-center">
              WATSUN INFRABUILD <span className="mx-2 text-indigo-400">⚡</span>
            </p>
            <div className="h-[1px] w-16 bg-gradient-to-l from-transparent to-slate-200"></div>
          </div>
          <div className="flex gap-4">
            <div className="w-1.5 h-1.5 rounded-full bg-slate-200"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-indigo-200"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-slate-200"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
