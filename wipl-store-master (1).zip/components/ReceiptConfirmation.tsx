
import React, { useState } from 'react';
import { db } from '../services/db';
import { User, InventoryRequest, RequestStatus } from '../types';

interface ReceiptConfirmationProps {
  user: User;
}

const ReceiptConfirmation: React.FC<ReceiptConfirmationProps> = ({ user }) => {
  const [requests, setRequests] = useState(db.getRequests().filter(r => 
    r.userId === user.id && 
    (r.status === RequestStatus.APPROVED || r.status === RequestStatus.ISSUED || r.status === RequestStatus.PARTIALLY_ISSUED)
  ));
  const [selectedReq, setSelectedReq] = useState<InventoryRequest | null>(null);
  const [notes, setNotes] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleConfirm = () => {
    if (!selectedReq) return;
    if (!imagePreview) return alert("Please upload a photo as proof of receipt.");

    db.updateRequest(selectedReq.id, {
      status: RequestStatus.CONFIRMED,
      requesterNotes: notes,
      requesterImage: imagePreview,
      confirmedAt: new Date().toISOString()
    });

    db.addLog({
      userId: user.id,
      userName: user.name,
      action: `CONFIRMED RECEIPT: Item ${selectedReq.itemName} received and logged.`,
      module: 'Handover Confirmation'
    });

    setRequests(db.getRequests().filter(r => 
      r.userId === user.id && 
      (r.status === RequestStatus.APPROVED || r.status === RequestStatus.ISSUED || r.status === RequestStatus.PARTIALLY_ISSUED)
    ));
    setSelectedReq(null);
    setNotes('');
    setImagePreview(null);
    alert("Receipt Confirmed. Handover record created.");
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h2 className="text-xl font-bold text-slate-900">Receipt Confirmation Center</h2>
        <p className="text-sm text-slate-500">Submit handover details and proof of receipt for approved requisitions.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {requests.map(req => (
          <div key={req.id} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-lg transition-all border-l-4 border-l-emerald-500">
            <div className="flex justify-between items-start mb-4">
              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded uppercase tracking-widest border border-emerald-100">
                Ready for Pickup
              </span>
              <span className="text-[10px] font-mono text-slate-400">{req.requestId}</span>
            </div>
            <h3 className="font-bold text-slate-900 mb-1">{req.itemName}</h3>
            <p className="text-xs text-slate-500 mb-4">Quantity: <span className="font-bold text-slate-900">{req.approvedQty}</span> {req.status === RequestStatus.ISSUED ? '(Issued by Store)' : '(Awaiting Issuance)'}</p>
            
            <button 
              onClick={() => setSelectedReq(req)}
              className="w-full py-2 bg-[#433878] text-white text-[11px] font-bold rounded-xl hover:bg-[#312e81] transition-all uppercase tracking-widest"
            >
              Sign Handover Details
            </button>
          </div>
        ))}

        {requests.length === 0 && (
          <div className="col-span-full py-20 text-center bg-white rounded-2xl border-2 border-dashed border-slate-200">
            <span className="text-4xl grayscale opacity-30">✅</span>
            <p className="mt-4 text-sm font-bold text-slate-400 uppercase tracking-widest">No Pending Handovers</p>
            <p className="text-xs text-slate-400">All received items have been documented.</p>
          </div>
        )}
      </div>

      {selectedReq && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-xl overflow-hidden border border-slate-200">
            <div className="px-8 py-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
              <div>
                <h3 className="font-black text-slate-900 uppercase tracking-tight text-lg">Secure Handover Form</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">WIPL Security Protocol</p>
              </div>
              <button onClick={() => setSelectedReq(null)} className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-100 rounded-xl">✕</button>
            </div>

            <div className="p-8 space-y-6">
              <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100 flex justify-between items-center">
                <div>
                  <p className="text-[10px] text-indigo-400 font-black uppercase mb-1">Asset Description</p>
                  <p className="text-sm font-bold text-indigo-900">{selectedReq.itemName}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-indigo-400 font-black uppercase mb-1">Authorized Qty</p>
                  <p className="text-sm font-bold text-indigo-900">{selectedReq.approvedQty} Units</p>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 ml-1 tracking-widest">Step 1: Upload Proof of Receipt</label>
                <div className="relative group">
                  {imagePreview ? (
                    <div className="relative h-48 rounded-2xl overflow-hidden border-2 border-emerald-500 shadow-lg">
                      <img src={imagePreview} className="w-full h-full object-cover" alt="Receipt preview" />
                      <button 
                        onClick={() => setImagePreview(null)}
                        className="absolute top-2 right-2 bg-red-500 text-white p-2 rounded-full shadow-lg hover:bg-red-600 transition-colors"
                      >✕</button>
                    </div>
                  ) : (
                    <label className="flex flex-col items-center justify-center h-48 border-2 border-dashed border-slate-200 rounded-2xl cursor-pointer hover:bg-slate-50 hover:border-indigo-300 transition-all">
                      <span className="text-4xl mb-2">📸</span>
                      <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Click to Upload Photo</span>
                      <span className="text-[10px] text-slate-400 mt-1 italic">Proof of physical possession</span>
                      <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} />
                    </label>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 ml-1 tracking-widest">Step 2: Utilization Details</label>
                <textarea 
                  className="w-full px-5 py-4 border border-slate-200 rounded-2xl text-sm h-28 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="Where will this item be used? Enter project code or location details..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                />
              </div>
            </div>

            <div className="px-8 py-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button 
                onClick={() => setSelectedReq(null)}
                className="px-6 py-3 text-xs font-black text-slate-500 hover:bg-slate-200 rounded-xl transition-colors uppercase tracking-widest"
              >Discard</button>
              <button 
                onClick={handleConfirm}
                className="px-10 py-3 text-xs font-black bg-[#433878] text-white hover:bg-[#312e81] rounded-xl transition-all shadow-xl shadow-indigo-100 uppercase tracking-widest"
              >Legalize Handover</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReceiptConfirmation;
