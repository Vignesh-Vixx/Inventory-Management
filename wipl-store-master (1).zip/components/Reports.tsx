
import React, { useState, useMemo } from 'react';
import { db } from '../services/db';

const Reports: React.FC = () => {
  const [previewData, setPreviewData] = useState<any[] | null>(null);
  const [previewTitle, setPreviewTitle] = useState<string>('');

  const monthlyConsumptionData = useMemo(() => {
    const issues = db.getIssues();
    const consumption: Record<string, any> = {};
    
    issues.forEach(issue => {
      const date = new Date(issue.issueDate);
      const monthKey = `${date.toLocaleString('default', { month: 'short' })} ${date.getFullYear()}`;
      
      const req = db.getRequests().find(r => r.id === issue.requestId);
      const itemName = req ? req.itemName : 'Unknown Asset';
      
      const key = `${monthKey}_${itemName}`;
      if (!consumption[key]) {
        consumption[key] = {
          Period: monthKey,
          Asset: itemName,
          'Total Issued': 0,
          'Gatepass Count': 0
        };
      }
      consumption[key]['Total Issued'] += issue.issuedQty;
      consumption[key]['Gatepass Count'] += 1;
    });

    return Object.values(consumption);
  }, []);

  const downloadCSV = (data: any[], filename: string) => {
    if (data.length === 0) {
      alert("No dynamic records found for this scope.");
      return;
    }
    const headers = Object.keys(data[0]).filter(k => k !== 'requesterImage');
    const csvContent = [
      headers.join(','),
      ...data.map(row => headers.map(header => JSON.stringify(row[header] || '')).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExport = (type: string) => {
    switch (type) {
      case 'Stock Ledger':
        downloadCSV(db.getItems(), 'stock_ledger_node_01.csv');
        break;
      case 'Request Status':
        downloadCSV(db.getRequests(), 'request_flow_report.csv');
        break;
      case 'Monthly Consumption':
        downloadCSV(monthlyConsumptionData, 'consumption_matrix.csv');
        break;
      case 'Audit Trail':
        downloadCSV(db.getLogs(), 'security_audit_logs.csv');
        break;
    }
  };

  const handlePreview = (type: string) => {
    setPreviewTitle(type);
    switch (type) {
      case 'Stock Ledger':
        setPreviewData(db.getItems());
        break;
      case 'Request Status':
        setPreviewData(db.getRequests());
        break;
      case 'Monthly Consumption':
        setPreviewData(monthlyConsumptionData);
        break;
      case 'Audit Trail':
        setPreviewData(db.getLogs());
        break;
    }
  };

  const reports = [
    { title: 'Stock Ledger', desc: 'Real-time asset valuation and categorical balance.', icon: '📑', color: 'indigo', count: db.getItems().length },
    { title: 'Request Status', desc: 'Lifecycle analytics of requisition nodes and approval flow.', icon: '📊', color: 'blue', count: db.getRequests().length },
    { title: 'Monthly Consumption', desc: 'Aggregated resource utilization over temporal nodes.', icon: '🗓️', color: 'emerald', count: monthlyConsumptionData.length },
    { title: 'Audit Trail', desc: 'Irreversible security logs of system events and access.', icon: '🛡️', color: 'slate', count: db.getLogs().length },
  ];

  return (
    <div className="space-y-10">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {reports.map((report, i) => (
          <div key={i} className="bg-white p-10 rounded-[44px] border border-slate-200 shadow-sm hover:shadow-2xl transition-all group">
            <div className="flex justify-between items-start mb-8">
              <div className="w-20 h-20 bg-slate-50 rounded-[28px] flex items-center justify-center text-4xl shadow-inner border border-slate-100 group-hover:scale-105 transition-transform">
                {report.icon}
              </div>
              <button 
                onClick={() => handleExport(report.title)}
                className="px-6 py-3 text-[10px] font-black bg-[#433878] text-white rounded-2xl hover:bg-[#312e81] transition-all shadow-xl shadow-indigo-100 uppercase tracking-widest"
              >
                Generate CSV
              </button>
            </div>
            <h3 className="font-black text-slate-900 text-xl mb-3">{report.title}</h3>
            <p className="text-[12px] text-slate-500 mb-10 leading-relaxed font-medium">{report.desc}</p>
            <div className="flex items-center justify-between pt-6 border-t border-slate-50">
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{report.count} Recorded Nodes</span>
              </div>
              <button 
                onClick={() => handlePreview(report.title)}
                className="text-[10px] font-black text-indigo-500 hover:text-indigo-700 uppercase tracking-widest px-4 py-2 hover:bg-indigo-50 rounded-xl transition-all"
              >
                Explore Grid
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Advanced Preview Modal */}
      {previewData && (
        <div className="fixed inset-0 bg-slate-900/80 flex items-center justify-center p-6 z-50 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-white rounded-[48px] shadow-2xl w-full max-w-7xl max-h-[90vh] overflow-hidden border border-white/20 flex flex-col scale-in-center">
            <div className="px-12 py-10 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center shrink-0">
              <div>
                <h3 className="font-black text-slate-900 uppercase tracking-tight text-2xl">Cluster Visualization: {previewTitle}</h3>
                <p className="text-[11px] text-slate-400 font-black uppercase tracking-[0.4em] mt-2">WIPL Operational Intelligence Matrix</p>
              </div>
              <button onClick={() => setPreviewData(null)} className="text-slate-400 hover:text-slate-900 p-4 hover:bg-slate-200 rounded-3xl transition-all text-2xl">✕</button>
            </div>

            <div className="flex-1 overflow-auto p-8 custom-scrollbar bg-white">
              {previewData.length > 0 ? (
                <table className="w-full text-left text-[11px] border-collapse min-w-max">
                  <thead className="sticky top-0 bg-slate-50 shadow-sm z-10">
                    <tr className="text-slate-500 font-black uppercase tracking-widest">
                      {Object.keys(previewData[0]).filter(k => k !== 'requesterImage').map(key => (
                        <th key={key} className="px-6 py-5 border-b border-slate-200">{key.replace(/([A-Z])/g, ' $1')}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-bold text-slate-600">
                    {previewData.map((row, i) => (
                      <tr key={i} className="hover:bg-indigo-50/40 transition-colors">
                        {Object.keys(row).filter(k => k !== 'requesterImage').map((key, j) => (
                          <td key={j} className="px-6 py-5 truncate max-w-[300px]">
                            {typeof row[key] === 'object' ? JSON.stringify(row[key]) : String(row[key])}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-slate-400 py-32 space-y-6">
                  <span className="text-7xl opacity-20">🗂️</span>
                  <p className="font-black uppercase tracking-[0.4em]">Zero Node Density Detected</p>
                </div>
              )}
            </div>

            <div className="px-12 py-10 bg-slate-50 border-t border-slate-100 flex justify-end shrink-0 gap-4">
               <button 
                onClick={() => setPreviewData(null)}
                className="px-10 py-5 bg-white text-slate-500 text-[11px] font-black rounded-[24px] hover:bg-slate-200 transition-all border border-slate-200 uppercase tracking-widest"
              >
                Close View
              </button>
              <button 
                onClick={() => handleExport(previewTitle)}
                className="px-12 py-5 bg-[#433878] text-white text-[11px] font-black rounded-[24px] hover:bg-[#312e81] transition-all shadow-2xl shadow-indigo-200 uppercase tracking-widest"
              >
                Commit to CSV
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Reports;
