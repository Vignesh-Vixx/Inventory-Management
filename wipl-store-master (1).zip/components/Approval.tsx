
import React, { useState } from 'react';
import { db } from '../services/db';
import { InventoryRequest, RequestStatus, User, Priority } from '../types';

interface ApprovalProps {
  user: User;
}

const Approval: React.FC<ApprovalProps> = ({ user }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<'All' | Priority>('All');
  const [requests, setRequests] = useState(db.getRequests().filter(r => r.status === RequestStatus.PENDING));
  const [items] = useState(db.getItems());
  const [selectedReq, setSelectedReq] = useState<InventoryRequest | null>(null);
  const [approvedQty, setApprovedQty] = useState(0);
  const [rejectionReason, setRejectionReason] = useState('');

  const filteredRequests = requests.filter(req => {
    const matchesSearch = req.userName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          req.requestId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPriority = priorityFilter === 'All' || req.priority === priorityFilter;
    return matchesSearch && matchesPriority;
  });

  const handleAction = (status: RequestStatus) => {
    if (!selectedReq) return;
    
    if (status === RequestStatus.REJECTED && !rejectionReason) {
      return alert('Rejection reason is required');
    }

    db.updateRequest(selectedReq.id, {
      status,
      approvedQty: status === RequestStatus.APPROVED ? approvedQty : 0,
      rejectionReason: status === RequestStatus.REJECTED ? rejectionReason : undefined
    });

    db.addLog({
      userId: user.id,
      userName: user.name,
      action: `${status} request ${selectedReq.requestId}`,
      module: 'Approvals'
    });

    setRequests(db.getRequests().filter(r => r.status === RequestStatus.PENDING));
    setSelectedReq(null);
    setApprovedQty(0);
    setRejectionReason('');
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <div className="relative flex-1">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">🔍</span>
          <input
            type="text"
            placeholder="Search by ID or Requester..."
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <select 
          className="px-4 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 font-medium"
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value as any)}
        >
          <option value="All">All Priorities</option>
          <option value={Priority.URGENT}>Urgent Only</option>
          <option value={Priority.NORMAL}>Normal Only</option>
        </select>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase font-bold border-b">
            <tr>
              <th className="px-6 py-4">Request ID</th>
              <th className="px-6 py-4">Requester</th>
              <th className="px-6 py-4">Item Details</th>
              <th className="px-6 py-4 text-center">Qty</th>
              <th className="px-6 py-4">Priority</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {filteredRequests.map(req => {
              const item = items.find(i => i.id === req.itemId);
              return (
                <tr key={req.id} className="hover:bg-amber-50/20 transition-colors group">
                  <td className="px-6 py-4 font-mono text-xs font-bold text-slate-900">{req.requestId}</td>
                  <td className="px-6 py-4">
                    <p className="font-bold text-slate-800">{req.userName}</p>
                    <p className="text-[10px] text-slate-400 font-medium">{req.department}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="font-bold text-slate-800">{req.itemName}</p>
                    {/* Fixed: Use currentStock instead of non-existent stock property */}
                    <p className="text-[10px] text-blue-600 font-bold">In Stock: {item?.currentStock || 0}</p>
                  </td>
                  <td className="px-6 py-4 text-center font-bold">{req.requestedQty}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${req.priority === Priority.URGENT ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-500'}`}>
                      {req.priority}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => {
                        setSelectedReq(req);
                        setApprovedQty(req.requestedQty);
                      }}
                      className="px-3 py-1 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800 transition-colors"
                    >
                      REVIEW
                    </button>
                  </td>
                </tr>
              );
            })}
            {filteredRequests.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                  <div className="flex flex-col items-center">
                    <span className="text-3xl mb-2">🎉</span>
                    <p className="font-medium text-sm">No pending approvals found.</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {selectedReq && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-200">
            <div className="px-8 py-5 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-slate-900">Requisition Review</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{selectedReq.requestId}</p>
              </div>
              <button onClick={() => setSelectedReq(null)} className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-100 rounded-lg">✕</button>
            </div>
            <div className="p-8 space-y-6">
              <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100">
                <p className="text-[10px] font-bold text-blue-400 uppercase mb-1">Requirement Reason</p>
                <p className="text-sm text-blue-900 leading-relaxed italic">"{selectedReq.reason}"</p>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Approve Quantity</label>
                  <input 
                    type="number" 
                    max={selectedReq.requestedQty}
                    className="w-full px-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    value={approvedQty}
                    onChange={e => setApprovedQty(Number(e.target.value))}
                  />
                  <p className="text-[10px] text-slate-400 mt-2 font-medium italic">Requested: {selectedReq.requestedQty} units</p>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Availability Status</label>
                  <div className="h-10 flex items-center px-4 bg-slate-50 text-slate-900 rounded-xl text-xs font-bold border border-slate-100">
                    {/* Fixed: Use currentStock instead of non-existent stock property */}
                    {items.find(i => i.id === selectedReq.itemId)?.currentStock || 0} Units in Warehouse
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5">Rejection Remarks (Required for Rejecting)</label>
                <textarea 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm h-24 focus:ring-2 focus:ring-red-500 outline-none"
                  placeholder="Provide a clear reason if you cannot approve this request..."
                  value={rejectionReason}
                  onChange={e => setRejectionReason(e.target.value)}
                />
              </div>
            </div>
            <div className="px-8 py-5 border-t border-slate-100 bg-slate-50/50 flex justify-end gap-3">
              <button 
                onClick={() => handleAction(RequestStatus.REJECTED)}
                className="px-6 py-2 text-xs font-bold text-red-600 border border-red-200 hover:bg-red-50 rounded-xl transition-all"
              >
                REJECT REQUEST
              </button>
              <button 
                onClick={() => handleAction(RequestStatus.APPROVED)}
                className="px-8 py-2 text-xs font-bold bg-green-600 text-white hover:bg-green-700 rounded-xl transition-all shadow-lg shadow-green-200"
              >
                APPROVE REQUISITION
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Approval;
