
import React, { useState } from 'react';
import { db } from '../services/db';
import { InventoryItem } from '../types';

const Inventory: React.FC = () => {
  const [items, setItems] = useState(db.getItems());
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);
  
  const [newItem, setNewItem] = useState<Partial<InventoryItem>>({
    category: 'General',
    itemCode: '',
    classification: 'Consumable',
    storageLocation: 'Main Store',
    itemName: '',
    uom: 'Nos',
    minStockReq: 0,
    openingStock: 0,
    issuedStock: 0,
    receivedStock: 0,
    returnedQty: 0,
    finalPhysicalStock: 0
  });

  const categories = ['All', ...Array.from(new Set(items.map(i => i.category)))];

  const filteredItems = items.filter(item => {
    const matchesSearch = item.itemName.toLowerCase().includes(search.toLowerCase()) ||
                         item.itemCode.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === 'All' || item.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const handleAddItem = () => {
    if (!newItem.itemCode || !newItem.itemName) return alert('Item Code and Name are required');
    
    const finalItem = {
      ...newItem,
      id: `item-${Date.now()}`,
      sNo: items.length + 1,
    } as InventoryItem;
    
    db.addItem(finalItem);
    setItems(db.getItems());
    setShowAddModal(false);
    
    // Reset form
    setNewItem({
      category: 'General',
      itemCode: '',
      classification: 'Consumable',
      storageLocation: 'Main Store',
      itemName: '',
      uom: 'Nos',
      minStockReq: 0,
      openingStock: 0,
      issuedStock: 0,
      receivedStock: 0,
      returnedQty: 0,
      finalPhysicalStock: 0
    });

    db.addLog({
      userId: 'admin',
      userName: 'Admin',
      action: `Created new item entry: ${finalItem.itemName}`,
      module: 'Inventory'
    });
  };

  const handleRemoveItem = (id: string, name: string) => {
    if (window.confirm(`PERMANENT REMOVAL: Are you sure you want to delete "${name}"? This will remove all associated history for this item code.`)) {
      db.deleteItem(id);
      // Immediately refresh the local state from the database
      const updatedItems = db.getItems();
      setItems(updatedItems);
      
      db.addLog({
        userId: 'admin',
        userName: 'Admin',
        action: `REMOVED ITEM: ${name} (ID: ${id})`,
        module: 'Inventory'
      });
    }
  };

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'Out of Stock': return 'bg-red-100 text-red-700 border-red-200';
      case 'Low Stock': return 'bg-amber-100 text-amber-700 border-amber-200';
      default: return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col lg:flex-row items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex flex-col md:flex-row items-center gap-3 w-full lg:w-auto">
          <div className="relative w-full md:w-80">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">🔍</span>
            <input
              type="text"
              placeholder="Filter by code or description..."
              className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select 
            className="w-full md:w-48 px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 font-medium"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
          >
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="w-full lg:w-auto px-6 py-2.5 bg-[#433878] text-white rounded-lg hover:bg-[#312e81] transition-all font-bold text-sm shadow-lg shadow-indigo-100 flex items-center justify-center gap-2"
        >
          <span>➕</span> Define New Stock Entry
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left table-auto min-w-[1800px]">
            <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase font-black tracking-widest border-b border-slate-200 sticky top-0 z-10">
              <tr>
                <th className="px-4 py-4 w-12 text-center">S.No</th>
                <th className="px-4 py-4">Category</th>
                <th className="px-4 py-4">Item Code</th>
                <th className="px-4 py-4">Classification</th>
                <th className="px-4 py-4">Storage Location</th>
                <th className="px-4 py-4 min-w-[250px]">Item Name (Descriptions)</th>
                <th className="px-4 py-4">UOM</th>
                <th className="px-4 py-4 text-center">Min Stock Req.</th>
                <th className="px-4 py-4 text-center">Opening Stock</th>
                <th className="px-4 py-4 text-center">Issued Stock</th>
                <th className="px-4 py-4 text-center">Received Stock</th>
                <th className="px-4 py-4 text-center">Returned Qty</th>
                <th className="px-4 py-4 text-center bg-indigo-50 font-bold">Current Stock</th>
                <th className="px-4 py-4 text-center">Final Physical Stock</th>
                <th className="px-4 py-4 text-center">Stock Status</th>
                <th className="px-4 py-4 text-center sticky right-0 bg-slate-50 shadow-[-4px_0_10px_rgba(0,0,0,0.05)]">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[11px] font-medium text-slate-600">
              {filteredItems.map((item, index) => (
                <tr key={item.id} className="hover:bg-indigo-50/30 transition-colors group">
                  <td className="px-4 py-4 text-center font-bold text-slate-400">{index + 1}</td>
                  <td className="px-4 py-4">{item.category}</td>
                  <td className="px-4 py-4">
                    <span className="font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                      {item.itemCode}
                    </span>
                  </td>
                  <td className="px-4 py-4">{item.classification}</td>
                  <td className="px-4 py-4 text-xs italic">{item.storageLocation}</td>
                  <td className="px-4 py-4 font-bold text-slate-900">{item.itemName}</td>
                  <td className="px-4 py-4 text-center">{item.uom}</td>
                  <td className="px-4 py-4 text-center">{item.minStockReq}</td>
                  <td className="px-4 py-4 text-center">{item.openingStock}</td>
                  <td className="px-4 py-4 text-center text-red-500 font-bold">-{item.issuedStock}</td>
                  <td className="px-4 py-4 text-center text-emerald-500 font-bold">+{item.receivedStock}</td>
                  <td className="px-4 py-4 text-center text-blue-500">+{item.returnedQty}</td>
                  <td className="px-4 py-4 text-center bg-indigo-50/50 font-black text-slate-900">{item.currentStock}</td>
                  <td className="px-4 py-4 text-center font-bold">{item.finalPhysicalStock}</td>
                  <td className="px-4 py-4 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase border ${getStatusStyle(item.stockStatus)}`}>
                      {item.stockStatus}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-center sticky right-0 bg-white group-hover:bg-indigo-50/30 transition-colors shadow-[-4px_0_10px_rgba(0,0,0,0.05)]">
                    <button 
                      onClick={() => handleRemoveItem(item.id, item.itemName)}
                      className="inline-flex items-center justify-center w-8 h-8 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                      title="Delete Item"
                    >
                      <span className="text-base">🗑️</span>
                    </button>
                  </td>
                </tr>
              ))}
              {filteredItems.length === 0 && (
                <tr>
                  <td colSpan={16} className="px-6 py-24 text-center text-slate-400 italic">
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-4xl grayscale opacity-50">📂</span>
                      <p className="text-sm font-bold uppercase tracking-widest">Inventory Ledger Empty</p>
                      <p className="text-xs">Super Admin action required to populate stock records.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 backdrop-blur-md overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl my-8 overflow-hidden border border-slate-200">
            <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <div>
                <h3 className="font-bold text-slate-900 text-lg">Define New Master Asset</h3>
                <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest">Formal Inventory Entry Sequence</p>
              </div>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-100 rounded-xl transition-colors">✕</button>
            </div>
            
            <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Identity Section */}
              <div className="md:col-span-3 pb-2 border-b border-slate-100">
                <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Basic Information</h4>
              </div>
              
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Category</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="e.g. Electrical"
                  value={newItem.category}
                  onChange={e => setNewItem({...newItem, category: e.target.value})}
                />
              </div>
              
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Item Code</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="ITM-WIPL-001"
                  value={newItem.itemCode}
                  onChange={e => setNewItem({...newItem, itemCode: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">UOM</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="Nos, Kg, Meters..."
                  value={newItem.uom}
                  onChange={e => setNewItem({...newItem, uom: e.target.value})}
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Item Name (Full Description)</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="Describe the asset in detail..."
                  value={newItem.itemName}
                  onChange={e => setNewItem({...newItem, itemName: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Classification</label>
                <select 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={newItem.classification}
                  onChange={e => setNewItem({...newItem, classification: e.target.value})}
                >
                  <option>Consumable</option>
                  <option>Non-Consumable</option>
                  <option>Capital Asset</option>
                  <option>Spare Part</option>
                </select>
              </div>

              {/* Logistics Section */}
              <div className="md:col-span-3 pt-4 pb-2 border-b border-slate-100">
                <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Storage & Stock Controls</h4>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Storage Location</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="e.g. Rack A-12"
                  value={newItem.storageLocation}
                  onChange={e => setNewItem({...newItem, storageLocation: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Min Stock Req.</label>
                <input 
                  type="number" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={newItem.minStockReq}
                  onChange={e => setNewItem({...newItem, minStockReq: Number(e.target.value)})}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1">Opening Stock</label>
                <input 
                  type="number" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none font-bold"
                  value={newItem.openingStock}
                  onChange={e => setNewItem({...newItem, openingStock: Number(e.target.value)})}
                />
              </div>

              {/* Quantitative Analysis Section */}
              <div className="md:col-span-3 pt-4 pb-2 border-b border-slate-100">
                <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Initial Balancing (Operational)</h4>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1 text-red-400">Issued Stock (Initial)</label>
                <input 
                  type="number" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-red-500 outline-none"
                  value={newItem.issuedStock}
                  onChange={e => setNewItem({...newItem, issuedStock: Number(e.target.value)})}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1 text-emerald-400">Received Stock (Initial)</label>
                <input 
                  type="number" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
                  value={newItem.receivedStock}
                  onChange={e => setNewItem({...newItem, receivedStock: Number(e.target.value)})}
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1.5 ml-1 text-blue-400">Returned Qty</label>
                <input 
                  type="number" 
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  value={newItem.returnedQty}
                  onChange={e => setNewItem({...newItem, returnedQty: Number(e.target.value)})}
                />
              </div>

              <div className="md:col-span-3 bg-indigo-50 p-6 rounded-2xl border border-indigo-100 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] mb-1">Calculated Current Stock</p>
                  <p className="text-3xl font-black text-indigo-900">
                    {(newItem.openingStock || 0) + (newItem.receivedStock || 0) - (newItem.issuedStock || 0) + (newItem.returnedQty || 0)}
                  </p>
                  <p className="text-[10px] text-indigo-400 mt-1 italic font-medium">Auto-derived: Opening + Received - Issued + Returned</p>
                </div>
                <div className="text-right">
                  <label className="block text-[10px] font-bold text-indigo-400 uppercase mb-1.5 mr-1">Final Physical Stock</label>
                  <input 
                    type="number" 
                    className="w-32 px-4 py-3 border border-indigo-200 rounded-xl text-lg font-black text-indigo-900 focus:ring-2 focus:ring-indigo-500 outline-none text-right"
                    value={newItem.finalPhysicalStock}
                    onChange={e => setNewItem({...newItem, finalPhysicalStock: Number(e.target.value)})}
                  />
                </div>
              </div>
            </div>

            <div className="px-8 py-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button 
                onClick={() => setShowAddModal(false)}
                className="px-6 py-3 text-xs font-black text-slate-500 hover:bg-slate-200 rounded-xl transition-colors uppercase tracking-widest"
              >
                DISCARD
              </button>
              <button 
                onClick={handleAddItem}
                className="px-10 py-3 text-xs font-black bg-[#433878] text-white hover:bg-[#312e81] rounded-xl transition-all shadow-xl shadow-indigo-100 uppercase tracking-widest"
              >
                LEGALIZE ENTRY
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Inventory;
