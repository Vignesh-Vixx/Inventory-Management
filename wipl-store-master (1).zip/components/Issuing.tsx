
import React, { useState } from 'react';
import { db } from '../services/db';
import { InventoryRequest, RequestStatus, User, Issue } from '../types';

interface IssuingProps {
  user: User;
}

const Issuing: React.FC<IssuingProps> = ({ user }) => {
  const [requests, setRequests] = useState(db.getRequests().filter(r => 
    r.status === RequestStatus.APPROVED || r.status === RequestStatus.PARTIALLY_ISSUED
  ));
  const [selectedReq, setSelectedReq] = useState<InventoryRequest | null>(null);
  const [issueQty, setIssueQty] = useState(0);
  const [remarks, setRemarks] = useState('');

  const handleIssue = () => {
    if (!selectedReq || issueQty <= 0) return;
    
    const remaining = selectedReq.approvedQty - selectedReq.issuedQty;
    if (issueQty > remaining) return alert('Cannot issue more than approved');

    const issue: Issue = {
      id: `iss-${Date.now()}`,
      requestId: selectedReq.id,
      issuedQty: issueQty,
      issueDate: new Date().toISOString(),
      issuedBy: user.name,
      remarks
    };

    db.addIssue(issue);
    db.addLog({
      userId: user.id,
      userName: user.name,
      action: `Issued ${issueQty} units for ${selectedReq.requestId}`,
      module: 'Issuing'
    });

    setRequests(db.getRequests().filter(r => 
      r.status === RequestStatus.APPROVED || r.status === RequestStatus.PARTIALLY_ISSUED
    ));
    setSelectedReq(null);
    setIssueQty(0);
    setRemarks('');
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase font-bold border-b">
            <tr>
              <th className="px-6 py-4">Request ID</th>
              <th className="px-6 py-4">Department</th>
              <th className="px-6 py-4">Item</th>
              <th className="px-6 py-4 text-center">Approved</th>
              <th className="px-6 py-4 text-center">Already Issued</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {requests.map(req => (
              <tr key={req.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4 font-mono text-xs font-bold">{req.requestId}</td>
                <td className="px-6 py-4 text-slate-600">{req.department}</td>
                <td className="px-6 py-4">
                  <p className="font-medium text-slate-900">{req.itemName}</p>
                </td>
                <td className="px-6 py-4 text-center font-bold text-green-600">{req.approvedQty}</td>
                <td className="px-6 py-4 text-center text-slate-500">{req.issuedQty || 0}</td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => {
                      setSelectedReq(req);
                      setIssueQty(req.approvedQty - (req.issuedQty || 0));
                    }}
                    className="px-4 py-1.5 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-lg text-xs font-bold uppercase transition-colors"
                  >
                    Issue
                  </button>
                </td>
              </tr>
            ))}
            {requests.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-10 text-center text-slate-400">
                  No pending issues. Great!
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {selectedReq && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="px-6 py-4 border-b bg-slate-50 flex justify-between items-center">
              <h3 className="font-bold text-slate-800">Item Issue Confirmation</h3>
              <button onClick={() => setSelectedReq(null)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex justify-between items-center bg-blue-50 p-4 rounded-lg">
                <div>
                  <p className="text-[10px] text-blue-600 font-bold uppercase">Item</p>
                  <p className="text-sm font-bold text-blue-900">{selectedReq.itemName}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-blue-600 font-bold uppercase">Pending</p>
                  <p className="text-sm font-bold text-blue-900">{selectedReq.approvedQty - (selectedReq.issuedQty || 0)} Units</p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Issue Quantity</label>
                <input 
                  type="number" 
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                  max={selectedReq.approvedQty - (selectedReq.issuedQty || 0)}
                  value={issueQty}
                  onChange={e => setIssueQty(Number(e.target.value))}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Gate Pass / Remarks</label>
                <textarea 
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm h-20"
                  placeholder="Enter gate pass number or other details..."
                  value={remarks}
                  onChange={e => setRemarks(e.target.value)}
                />
              </div>
            </div>
            <div className="px-6 py-4 border-t flex justify-end gap-3">
              <button 
                onClick={() => setSelectedReq(null)}
                className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button 
                onClick={handleIssue}
                className="px-6 py-2 text-sm font-medium bg-blue-600 text-white hover:bg-blue-700 rounded-lg"
              >
                Confirm Issue
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Issuing;
