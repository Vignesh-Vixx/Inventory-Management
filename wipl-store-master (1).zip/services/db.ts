
import { 
  User, UserRole, InventoryItem, InventoryRequest, 
  RequestStatus, Priority, Issue, AuditLog 
} from '../types';

const initialUsers: User[] = [
  { 
    id: 'u1', 
    name: 'WIPL Super Admin', 
    email: 'superadmin@wipl.com', 
    password: 'WIPL@Admin#2025', 
    role: UserRole.SUPER_ADMIN, 
    department: 'Executive Management' 
  },
  { 
    id: 'u2', 
    name: 'Procurement Manager', 
    email: 'admin@wipl.com', 
    password: 'AdminPassword123', 
    role: UserRole.ADMIN, 
    department: 'Procurement' 
  },
  { 
    id: 'u3', 
    name: 'Field Technician', 
    email: 'tech@wipl.com', 
    password: 'TechPassword123', 
    role: UserRole.TECHNICAL_TEAM, 
    department: 'Maintenance' 
  },
  { 
    id: 'u4', 
    name: 'Warehouse Keeper', 
    email: 'keeper@wipl.com', 
    password: 'KeeperPassword123', 
    role: UserRole.STORE_KEEPER, 
    department: 'Logistics' 
  },
];

// Initializing as empty as requested
let items: InventoryItem[] = [];
let users: User[] = [...initialUsers];
let requests: InventoryRequest[] = [];
let issues: Issue[] = [];
let auditLogs: AuditLog[] = [];

export const db = {
  // Users
  getUsers: () => [...users],
  addUser: (user: User) => {
    users = [...users, user];
  },
  deleteUser: (id: string) => {
    users = users.filter(u => u.id !== id);
  },
  
  // Inventory
  getItems: () => [...items],
  updateItem: (id: string, updates: Partial<InventoryItem>) => {
    items = items.map(item => {
      if (item.id === id) {
        const merged = { ...item, ...updates };
        // Recalculate Current Stock
        merged.currentStock = (merged.openingStock || 0) + (merged.receivedStock || 0) - (merged.issuedStock || 0) + (merged.returnedQty || 0);
        // Update Status
        merged.stockStatus = merged.currentStock <= merged.minStockReq ? 'Low Stock' : 'In Stock';
        if (merged.currentStock === 0) merged.stockStatus = 'Out of Stock';
        return merged;
      }
      return item;
    });
  },
  addItem: (item: InventoryItem) => {
    // Force calculation on add
    item.currentStock = (item.openingStock || 0) + (item.receivedStock || 0) - (item.issuedStock || 0) + (item.returnedQty || 0);
    item.stockStatus = item.currentStock <= item.minStockReq ? 'Low Stock' : 'In Stock';
    if (item.currentStock === 0) item.stockStatus = 'Out of Stock';
    items = [...items, item];
  },
  deleteItem: (id: string) => { 
    items = items.filter(item => item.id !== id); 
  },

  // Requests
  getRequests: () => [...requests],
  addRequest: (req: InventoryRequest) => {
    requests = [...requests, req];
  },
  updateRequest: (id: string, updates: Partial<InventoryRequest>) => {
    requests = requests.map(req => req.id === id ? { ...req, ...updates } : req);
  },

  // Issues
  getIssues: () => [...issues],
  addIssue: (issue: Issue) => {
    issues = [...issues, issue];
    const req = requests.find(r => r.id === issue.requestId);
    if (req) {
      const newIssuedTotal = (req.issuedQty || 0) + issue.issuedQty;
      const status = newIssuedTotal >= req.approvedQty ? RequestStatus.ISSUED : RequestStatus.PARTIALLY_ISSUED;
      
      db.updateRequest(req.id, { 
        issuedQty: newIssuedTotal,
        status: status
      });

      // Update Inventory Issued Stock
      const item = items.find(i => i.id === req.itemId);
      if (item) {
        db.updateItem(item.id, { issuedStock: (item.issuedStock || 0) + issue.issuedQty });
      }
    }
  },

  // Audit
  getLogs: () => [...auditLogs],
  addLog: (log: Omit<AuditLog, 'id' | 'timestamp'>) => {
    auditLogs.push({
      ...log,
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString()
    });
  }
};
