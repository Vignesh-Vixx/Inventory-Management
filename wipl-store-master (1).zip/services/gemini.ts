
import { GoogleGenAI } from "@google/genai";
import { InventoryItem, InventoryRequest } from "../types";

export async function getInventoryInsights(items: InventoryItem[], requests: InventoryRequest[]) {
  // Create a new instance right before making an API call to ensure 
  // it uses the most up-to-date API key (e.g., after user selects their own).
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `
    Analyze the following inventory data for WATSUN INFRABUILD and provide 3-4 professional, actionable bullet points for the warehouse manager.
    Focus on low stock items, high demand categories, and potential stockouts.
    
    Items: ${JSON.stringify(items.map(i => ({ name: i.itemName, stock: i.currentStock, reorder: i.minStockReq })))}
    Recent Requests: ${JSON.stringify(requests.slice(-10).map(r => ({ item: r.itemName, qty: r.requestedQty, date: r.createdAt })))}
    
    Format the response as a clear list of professional insights.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text;
  } catch (error: any) {
    console.error("AI Insight Error:", error);
    
    // Attempt to parse structured error message for 429/RESOURCE_EXHAUSTED
    const errorString = typeof error === 'string' ? error : JSON.stringify(error);
    
    if (
      errorString.includes("RESOURCE_EXHAUSTED") || 
      errorString.includes("429") || 
      error?.status === 429 ||
      error?.code === 429
    ) {
      return "QUOTA_EXHAUSTED";
    }
    
    // Handle other errors gracefully
    if (errorString.includes("Requested entity was not found")) {
      // This often happens if the key selection state is invalid
      return "KEY_INVALID";
    }

    return "Unable to synchronize neural insights at this time.";
  }
}
